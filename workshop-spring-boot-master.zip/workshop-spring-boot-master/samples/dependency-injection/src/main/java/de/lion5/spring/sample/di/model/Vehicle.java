package de.lion5.spring.sample.di.model;

public interface Vehicle {
    public String getWheelInfo();
}
