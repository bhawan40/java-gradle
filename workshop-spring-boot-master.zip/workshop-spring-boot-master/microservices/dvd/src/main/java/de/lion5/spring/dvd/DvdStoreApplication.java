package de.lion5.spring.dvd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DvdStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(DvdStoreApplication.class, args);
	}

}
