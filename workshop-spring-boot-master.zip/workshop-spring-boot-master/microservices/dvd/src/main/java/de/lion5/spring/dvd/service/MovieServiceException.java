package de.lion5.spring.dvd.service;

public class MovieServiceException extends Throwable {
    public MovieServiceException(String s) {
        super(s);
    }
}
