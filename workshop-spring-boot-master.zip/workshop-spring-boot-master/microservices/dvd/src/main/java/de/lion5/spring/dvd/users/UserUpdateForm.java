package de.lion5.spring.dvd.users;

import lombok.Data;

@Data
public class UserUpdateForm {
    private String newRole;
}
